let campoSeleccionado = ''; // Campo activo ('peso' o 'altura')
let peso = ''; // Almacena el peso ingresado
let altura = ''; // Almacena la altura ingresada

function hablar(texto) {
    const speech = new SpeechSynthesisUtterance(texto);
    speech.rate = 1.5;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(speech);
}

function seleccionarCampo(campo) {
    campoSeleccionado = campo;
    document.getElementById('campoActual').value = campo === 'peso' ? peso : altura;
    hablar(`Campo seleccionado: ${campo}`);
}

function agregarNumero(numero) {
    if (campoSeleccionado === '') {
        hablar('Seleccione un campo primero.');
        return;
    }
    if (campoSeleccionado === 'peso') {
        peso += numero;
        document.getElementById('campoActual').value = peso;
    } else if (campoSeleccionado === 'altura') {
        altura += numero;
        document.getElementById('campoActual').value = altura;
    }
    hablar(numero);
}

function borrarUltimo() {
    if (campoSeleccionado === 'peso') {
        peso = peso.slice(0, -1);
        document.getElementById('campoActual').value = peso;
    } else if (campoSeleccionado === 'altura') {
        altura = altura.slice(0, -1);
        document.getElementById('campoActual').value = altura;
    }
    hablar('Carácter borrado');
}

function resetear() {
    peso = '';
    altura = '';
    campoSeleccionado = '';
    document.getElementById('campoActual').value = '';
    document.getElementById('resultado').innerText = 'Ingrese peso y altura para calcular el IMC.';
    hablar('Campos reseteados');
}

function calcularIMC() {
    const pesoNum = parseFloat(peso);
    const alturaNum = parseFloat(altura);

    if (!pesoNum || !alturaNum || pesoNum <= 0 || alturaNum <= 0) {
        const mensaje = 'Por favor, ingrese valores válidos.';
        document.getElementById('resultado').innerText = mensaje;
        hablar(mensaje);
        return;
    }

    const alturaMetros = alturaNum / 100;
    const imc = pesoNum / (alturaMetros ** 2);

    let clasificacion = '';
    if (imc < 18.5) clasificacion = 'bajo peso';
    else if (imc < 25) clasificacion = 'peso normal';
    else if (imc < 30) clasificacion = 'sobrepeso';
    else clasificacion = 'obesidad';

    const mensaje = `Su IMC es ${imc.toFixed(2)}. Usted tiene ${clasificacion}.`;
    document.getElementById('resultado').innerText = mensaje;
    hablar(mensaje);
}
