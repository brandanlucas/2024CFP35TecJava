import java.util.Scanner;

public class TrabajoFinal1_CalculadoraIMC {

    // Códigos ANSI para colores
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_CYAN = "\u001B[36m";

    public static void main(String[] args) {
        // Mostrar un banner con colores y un dibujo de calculadora
        System.out.println(ANSI_BLUE + "************************************************" + ANSI_RESET);
        System.out.println(ANSI_GREEN + "*              Calculadora de IMC              *" + ANSI_RESET);
        System.out.println(ANSI_BLUE + "************************************************" + ANSI_RESET);

        // Dibujo de una calculadora
        System.out.println(ANSI_CYAN + "     _____________________");
        System.out.println("    |  _________________  |");
        System.out.println("    | |                 | |");
        System.out.println("    | |    IMC  CALC    | |");
        System.out.println("    | |_________________| |");
        System.out.println("    |  ___ ___ ___   ___  |");
        System.out.println("    | | 7 | 8 | 9 | | + | |");
        System.out.println("    | |___|___|___| |___| |");
        System.out.println("    | | 4 | 5 | 6 | | - | |");
        System.out.println("    | |___|___|___| |___| |");
        System.out.println("    | | 1 | 2 | 3 | | * | |");
        System.out.println("    | |___|___|___| |___| |");
        System.out.println("    | | . | 0 | = | | / | |");
        System.out.println("    | |___|___|___| |___| |");
        System.out.println("    |_____________________|" + ANSI_RESET);

        // Entrada de datos
        Scanner scanner = new Scanner(System.in);
        System.out.print(ANSI_YELLOW + "Ingrese su peso en kilogramos(solo números): " + ANSI_RESET);
        double peso = scanner.nextDouble();
        System.out.print(ANSI_YELLOW + "Ingrese su altura en metros(separado por coma): " + ANSI_RESET);
        double altura = scanner.nextDouble();

        // Calculo del IMC
        double imc = peso / (altura * altura);
        System.out.println(ANSI_CYAN + "Su IMC es: " + imc + ANSI_RESET);

        // Determinación del estado según el IMC
        String estado;
        String colorEstado = ANSI_RESET;

        if (imc <= 15) {
            estado = "Delgadez muy severa";
            colorEstado = ANSI_RED;
        } else if (imc <= 15.9) {
            estado = "Delgadez severa";
            colorEstado = ANSI_RED;
        } else if (imc <= 18.4) {
            estado = "Delgadez";
            colorEstado = ANSI_YELLOW;
        } else if (imc <= 24.9) {
            estado = "Normal";
            colorEstado = ANSI_GREEN;
        } else if (imc <= 29.9) {
            estado = "Sobrepeso";
            colorEstado = ANSI_YELLOW;
        } else if (imc <= 34.9) {
            estado = "Obesidad moderada";
            colorEstado = ANSI_RED;
        } else if (imc <= 39.9) {
            estado = "Obesidad severa";
            colorEstado = ANSI_RED;
        } else {
            estado = "Obesidad mórbida";
            colorEstado = ANSI_RED;
        }

        // Resultado final con colores
        System.out.println(ANSI_BLUE + "************************************************" + ANSI_RESET);
        System.out.println(colorEstado + "Estado: " + estado + ANSI_RESET);
        System.out.println(ANSI_BLUE + "************************************************" + ANSI_RESET);
    }
}
