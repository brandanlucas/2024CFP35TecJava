import java.util.Scanner;

public class TrabajoFinal2_CalculadoraIMC {

    // Códigos ANSI para colores
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_CYAN = "\u001B[36m";

    public static void main(String[] args) {
        // Mostrar un banner con colores y un dibujo de calculadora
        System.out.println(ANSI_BLUE + "************************************************" + ANSI_RESET);
        System.out.println(ANSI_GREEN + "*              Calculadora de IMC              *" + ANSI_RESET);
        System.out.println(ANSI_BLUE + "************************************************" + ANSI_RESET);

        // Dibujo de una calculadora
        System.out.println(ANSI_CYAN + "     _____________________");
        System.out.println("    |  _________________  |");
        System.out.println("    | |                 | |");
        System.out.println("    | |    IMC  CALC    | |");
        System.out.println("    | |_________________| |");
        System.out.println("    |  ___ ___ ___   ___  |");
        System.out.println("    | | 7 | 8 | 9 | | + | |");
        System.out.println("    | |___|___|___| |___| |");
        System.out.println("    | | 4 | 5 | 6 | | - | |");
        System.out.println("    | |___|___|___| |___| |");
        System.out.println("    | | 1 | 2 | 3 | | * | |");
        System.out.println("    | |___|___|___| |___| |");
        System.out.println("    | | . | 0 | = | | / | |");
        System.out.println("    | |___|___|___| |___| |");
        System.out.println("    |_____________________|" + ANSI_RESET);

        // Entrada de datos
        Scanner scanner = new Scanner(System.in);
        System.out.print(ANSI_YELLOW + "Ingrese su peso en kilogramos (solo números): " + ANSI_RESET);
        double peso = scanner.nextDouble();
        System.out.print(ANSI_YELLOW + "Ingrese su altura en metros (separado por coma): " + ANSI_RESET);
        double altura = scanner.nextDouble();

        // Calcular IMC utilizando la función
        double imc = calcularMasaCorporal(peso, altura);

        // Obtener estado utilizando la función
        String estado = obtenerEstado(imc);

        // Resultado final con colores
        System.out.println(ANSI_CYAN + "************************************************" + ANSI_RESET);
        System.out.printf(ANSI_BLUE + "Peso: %.2f kg%n", peso);
        System.out.printf("Altura: %.2f m%n", altura);
        System.out.printf("IMC: %.2f%n", imc);
        System.out.println("Estado: " + estado + ANSI_RESET);
        System.out.println(ANSI_CYAN + "************************************************" + ANSI_RESET);
    }

    /**
     * Calcula el índice de masa corporal (IMC).
     *
     * @param peso   Peso en kilogramos.
     * @param altura Altura en metros.
     * @return El índice de masa corporal (IMC).
     */
    public static double calcularMasaCorporal(double peso, double altura) {
        return peso / (altura * altura);
    }

    /**
     * Determina el estado según el índice de masa corporal (IMC).
     *
     * @param imc El índice de masa corporal (IMC).
     * @return Un String con el estado correspondiente.
     */
    public static String obtenerEstado(double imc) {
        if (imc <= 15) {
            return ANSI_RED + "Delgadez muy severa" + ANSI_RESET;
        } else if (imc <= 15.9) {
            return ANSI_RED + "Delgadez severa" + ANSI_RESET;
        } else if (imc <= 18.4) {
            return ANSI_YELLOW + "Delgadez" + ANSI_RESET;
        } else if (imc <= 24.9) {
            return ANSI_GREEN + "Normal" + ANSI_RESET;
        } else if (imc <= 29.9) {
            return ANSI_YELLOW + "Sobrepeso" + ANSI_RESET;
        } else if (imc <= 34.9) {
            return ANSI_RED + "Obesidad moderada" + ANSI_RESET;
        } else if (imc <= 39.9) {
            return ANSI_RED + "Obesidad severa" + ANSI_RESET;
        } else {
            return ANSI_RED + "Obesidad mórbida" + ANSI_RESET;
        }
    }
}
